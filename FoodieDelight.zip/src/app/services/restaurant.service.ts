import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  private baseUrl = 'api/restaurants';

  constructor(private http: HttpClient) { }

  getRestaurants(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  getRestaurant(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  addRestaurant(restaurant: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, restaurant);
  }

  updateRestaurant(id: number, restaurant: Object): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, restaurant);
  }

  deleteRestaurant(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}

import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RestaurantService } from './restaurant.service';

describe('RestaurantService', () => {
  let service: RestaurantService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [RestaurantService]
    });
    service = TestBed.inject(RestaurantService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch restaurants', () => {
    const dummyRestaurants = [
      { id: 1, name: 'Pizza Palace', description: 'Delicious pizzas and more.', location: '123 Main St' },
      { id: 2, name: 'Sushi World', description: 'Fresh and tasty sushi.', location: '456 Elm St' }
    ];

    service.getRestaurants().subscribe(restaurants => {
      expect(restaurants.length).toBe(2);
      expect(restaurants).toEqual(dummyRestaurants);
    });

    const req = httpMock.expectOne('api/restaurants');
    expect(req.request.method).toBe('GET');
    req.flush(dummyRestaurants);
  });

  it('should add a restaurant', () => {
    const newRestaurant = { id: 3, name: 'Burger Barn', description: 'Juicy burgers and fries.', location: '789 Oak St' };

    service.addRestaurant(newRestaurant).subscribe(restaurant => {
      expect(restaurant).toEqual(newRestaurant);
    });

    const req = httpMock.expectOne('api/restaurants');
    expect(req.request.method).toBe('POST');
    req.flush(newRestaurant);
  });

  it('should update a restaurant', () => {
    const updatedRestaurant = { id: 1, name: 'Updated Pizza Palace', description: 'Updated description', location: '123 Main St' };

    service.updateRestaurant(1, updatedRestaurant).subscribe(restaurant => {
      expect(restaurant).toEqual(updatedRestaurant);
    });

    const req = httpMock.expectOne('api/restaurants/1');
    expect(req.request.method).toBe('PUT');
    req.flush(updatedRestaurant);
  });

  it('should delete a restaurant', () => {
    service.deleteRestaurant(1).subscribe(response => {
      expect(response).toEqual({});
    });

    const req = httpMock.expectOne('api/restaurants/1');
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RestaurantFormComponent } from './restaurant-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RestaurantService } from '../../services/restaurant.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('RestaurantFormComponent', () => {
  let component: RestaurantFormComponent;
  let fixture: ComponentFixture<RestaurantFormComponent>;
  const restaurantService = jasmine.createSpyObj<RestaurantService>('RestaurantService', ['getRestaurant', 'updateRestaurant', 'addRestaurant']);
  const activatedRoute = {
    params: of({id: 1})
  }

  const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        MatButtonModule,
        MatInputModule,
        MatFormFieldModule,
        BrowserAnimationsModule,
        RouterTestingModule
      ],
      declarations: [RestaurantFormComponent],
      providers: [
        { provide: Router, useValue: routerSpy },
        { provide: RestaurantService, useValue: restaurantService },
        { provide: ActivatedRoute, useValue: activatedRoute }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantFormComponent);
    component = fixture.componentInstance;
    restaurantService.getRestaurant.and.returnValue(of(
      { id: 1, name: 'Pizza Palace', description: 'Delicious pizzas and more.', location: '123 Main St' }));
    restaurantService.addRestaurant.and.returnValue(of({}));
    restaurantService.updateRestaurant.and.returnValue(of({}));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create a form with 3 controls', () => {
    expect(Object.keys(component.restaurantForm.controls)).toEqual(['name', 'description', 'location']);
  });

  it('should call addRestaurant on submit', () => {
    component.restaurantForm.setValue({ name: 'Test', description: 'Test desc', location: 'Test loc' });
    component.isEditMode = false;
    component.onSubmit();
    expect(restaurantService.addRestaurant).toHaveBeenCalled();
  });

  it('should call updateRestaurant on submit', () => {
    component.restaurantForm.setValue({ name: 'Test', description: 'Test desc', location: 'Test loc' });
    component.isEditMode = true;
    component.onSubmit();
    expect(restaurantService.updateRestaurant).toHaveBeenCalled();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RestaurantService } from '../../services/restaurant.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-restaurant-form',
  templateUrl: './restaurant-form.component.html',
  styleUrls: ['./restaurant-form.component.scss']
})
export class RestaurantFormComponent implements OnInit {
  restaurantForm!: FormGroup;
  isEditMode = false;
  restaurantId!: number;

  constructor(
    private fb: FormBuilder,
    private restaurantService: RestaurantService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.restaurantForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      location: ['', Validators.required]
    });

    this.route.params.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.restaurantId = params['id'];
        this.restaurantService.getRestaurant(this.restaurantId).subscribe(data => {
          this.restaurantForm.patchValue(data);
        }, error => {
          console.log(error);
        });
      }
    });
  }

  onSubmit() {
    if (this.restaurantForm.invalid) {
      return;
    }

    if (this.isEditMode) {
      const payload = { ...this.restaurantForm.value, id: Number(this.restaurantId) };
      this.restaurantService.updateRestaurant(this.restaurantId, payload).subscribe(() => {
        this.router.navigate(['/restaurants']);
      }, error => {
        console.log(error);
      });
    } else {
      this.restaurantService.addRestaurant(this.restaurantForm.value).subscribe(() => {
        this.router.navigate(['/restaurants']);
      }, error => {
        console.log(error);
      });
    }
  }
}

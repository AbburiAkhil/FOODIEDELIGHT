import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService {

  createDb() {
    const restaurants = [
      { id: 1, name: 'Pizza Palace', description: 'Delicious pizzas and more.', location: '123 Main St' },
      { id: 2, name: 'Sushi World', description: 'Fresh and tasty sushi.', location: '456 Elm St' },
      { id: 3, name: 'Burger Barn', description: 'Juicy burgers and fries.', location: '789 Oak St' }
    ];
    return { restaurants };
  }
  
}
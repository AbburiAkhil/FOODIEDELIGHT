import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RestaurantListComponent } from './restaurant-list.component';
import { RestaurantService } from '../../services/restaurant.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MatTableModule } from '@angular/material/table';
import { of } from 'rxjs';

describe('RestaurantListComponent', () => {
  let component: RestaurantListComponent;
  let fixture: ComponentFixture<RestaurantListComponent>;
  let restaurantService: RestaurantService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, MatTableModule],
      declarations: [RestaurantListComponent],
      providers: [RestaurantService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantListComponent);
    component = fixture.componentInstance;
    restaurantService = TestBed.inject(RestaurantService);

    spyOn(restaurantService, 'getRestaurants').and.returnValue(of([
      { id: 1, name: 'Pizza Palace', description: 'Delicious pizzas and more.', location: '123 Main St' },
      { id: 2, name: 'Sushi World', description: 'Fresh and tasty sushi.', location: '456 Elm St' }
    ]));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch restaurants on init', () => {
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.dataSource.data.length).toBe(2);
  });

  it('should delete restaurant', () => {
    spyOn(restaurantService, 'deleteRestaurant').and.returnValue(of({}));
    component.deleteRestaurant(1);
    expect(restaurantService.deleteRestaurant).toHaveBeenCalledWith(1);
  });
});
